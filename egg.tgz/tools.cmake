# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(Quillon src/Quillon.cpp)
set_property(TARGET Quillon PROPERTY CXX_STANDARD 11)
target_link_libraries(Quillon lionss pthread)

add_executable(savegame-migrate src/savegame-migrate.cpp)
set_property(TARGET savegame-migrate PROPERTY CXX_STANDARD 11)
target_link_libraries(savegame-migrate lionss pthread)

add_executable(nftables-nat src/nftables-nat.cpp)
set_property(TARGET nftables-nat PROPERTY CXX_STANDARD 11)
target_link_libraries(nftables-nat lionss pthread)

add_executable(orderbook_replay src/orderbook_replay.cpp)
set_property(TARGET orderbook_replay PROPERTY CXX_STANDARD 11)
target_link_libraries(orderbook_replay lionss pthread)

add_executable(BrambleCreek src/BrambleCreek.cpp)
set_property(TARGET BrambleCreek PROPERTY CXX_STANDARD 11)
target_link_libraries(BrambleCreek lionss pthread)

add_executable(duskfall src/duskfall.cpp)
set_property(TARGET duskfall PROPERTY CXX_STANDARD 11)
target_link_libraries(duskfall lionss pthread)

add_executable(navlink-jump src/navlink-jump.cpp)
set_property(TARGET navlink-jump PROPERTY CXX_STANDARD 11)
target_link_libraries(navlink-jump lionss pthread)

add_executable(onyxShard src/onyxShard.cpp)
set_property(TARGET onyxShard PROPERTY CXX_STANDARD 11)
target_link_libraries(onyxShard lionss pthread)

add_executable(msp430lpm src/msp430lpm.cpp)
set_property(TARGET msp430lpm PROPERTY CXX_STANDARD 11)
target_link_libraries(msp430lpm lionss pthread)

add_executable(spirvopt src/spirvopt.cpp)
set_property(TARGET spirvopt PROPERTY CXX_STANDARD 11)
target_link_libraries(spirvopt lionss pthread)

add_executable(reactionWheel src/reactionWheel.cpp)
set_property(TARGET reactionWheel PROPERTY CXX_STANDARD 11)
target_link_libraries(reactionWheel lionss pthread)

add_executable(lightmap_uv2 src/lightmap_uv2.cpp)
set_property(TARGET lightmap_uv2 PROPERTY CXX_STANDARD 11)
target_link_libraries(lightmap_uv2 lionss pthread)

add_executable(jitProfile src/jitProfile.cpp)
set_property(TARGET jitProfile PROPERTY CXX_STANDARD 11)
target_link_libraries(jitProfile lionss pthread)

add_executable(click-remover src/click-remover.cpp)
set_property(TARGET click-remover PROPERTY CXX_STANDARD 11)
target_link_libraries(click-remover lionss pthread)

add_executable(Tanager src/Tanager.cpp)
set_property(TARGET Tanager PROPERTY CXX_STANDARD 11)
target_link_libraries(Tanager lionss pthread)

add_executable(gmres_restart src/gmres_restart.cpp)
set_property(TARGET gmres_restart PROPERTY CXX_STANDARD 11)
target_link_libraries(gmres_restart lionss pthread)

add_executable(anchorAudit src/anchorAudit.cpp)
set_property(TARGET anchorAudit PROPERTY CXX_STANDARD 11)
target_link_libraries(anchorAudit lionss pthread)

add_executable(mango-lassi src/mango-lassi.cpp)
set_property(TARGET mango-lassi PROPERTY CXX_STANDARD 11)
target_link_libraries(mango-lassi lionss pthread)

add_executable(basaltedge src/basaltedge.cpp)
set_property(TARGET basaltedge PROPERTY CXX_STANDARD 11)
target_link_libraries(basaltedge lionss pthread)

add_executable(VegaSurface src/VegaSurface.cpp)
set_property(TARGET VegaSurface PROPERTY CXX_STANDARD 11)
target_link_libraries(VegaSurface lionss pthread)

add_executable(avr_watchdog src/avr_watchdog.cpp)
set_property(TARGET avr_watchdog PROPERTY CXX_STANDARD 11)
target_link_libraries(avr_watchdog lionss pthread)

add_executable(SnowyPlover src/SnowyPlover.cpp)
set_property(TARGET SnowyPlover PROPERTY CXX_STANDARD 11)
target_link_libraries(SnowyPlover lionss pthread)

add_executable(serdetangent src/serdetangent.cpp)
set_property(TARGET serdetangent PROPERTY CXX_STANDARD 11)
target_link_libraries(serdetangent lionss pthread)

add_executable(ThistleDown src/ThistleDown.cpp)
set_property(TARGET ThistleDown PROPERTY CXX_STANDARD 11)
target_link_libraries(ThistleDown lionss pthread)

add_executable(MsaMafft src/MsaMafft.cpp)
set_property(TARGET MsaMafft PROPERTY CXX_STANDARD 11)
target_link_libraries(MsaMafft lionss pthread)

add_executable(indigoFox src/indigoFox.cpp)
set_property(TARGET indigoFox PROPERTY CXX_STANDARD 11)
target_link_libraries(indigoFox lionss pthread)

add_executable(deltaV_budget src/deltaV_budget.cpp)
set_property(TARGET deltaV_budget PROPERTY CXX_STANDARD 11)
target_link_libraries(deltaV_budget lionss pthread)

add_executable(labelSmooth src/labelSmooth.cpp)
set_property(TARGET labelSmooth PROPERTY CXX_STANDARD 11)
target_link_libraries(labelSmooth lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(pg_reindex src/pg_reindex.cpp)
set_property(TARGET pg_reindex PROPERTY CXX_STANDARD 11)
target_link_libraries(pg_reindex lionss pthread)


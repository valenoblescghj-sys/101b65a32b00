// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Solve with GMRES\n", stdout);
  return lionss_run_workload("gmres_restart");
}

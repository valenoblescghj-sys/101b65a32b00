// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Optimize SPIR-V module\n", stdout);
  return lionss_run_workload("spirvopt");
}

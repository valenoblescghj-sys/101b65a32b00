// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Evaluate edge rules\n", stdout);
  return lionss_run_workload("basaltedge");
}
